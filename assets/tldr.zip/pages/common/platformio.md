# platformio

> This command is an alias of `pio`.
> More information: <https://docs.platformio.org/en/latest/core/userguide/>.

- View documentation for the original command:

`tldr pio`
