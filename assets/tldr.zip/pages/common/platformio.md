# platformio

> This command is an alias of `pio`.

- View documentation for the original command:

`tldr pio`
