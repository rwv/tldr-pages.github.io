# freshclam

> Update virus definitions for ClamAV antivirus program.
> More information: <https://www.clamav.net>.

- Update virus definitions:

`freshclam`
