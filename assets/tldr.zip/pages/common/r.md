# r

> R language interpreter.
> More information: <https://www.r-project.org>.

- Start an R interactive shell (REPL):

`R`

- Check R version:

`R --version`

- Execute a file:

`R -f {{file.R}}`
