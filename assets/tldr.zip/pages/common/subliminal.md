# subliminal

> Python-based subtitle downloader.
> Homepage: <https://github.com/Diaoul/subliminal>.

- Download English subtitles for a video:

`subliminal download -l {{en}} {{video.ext}}`
