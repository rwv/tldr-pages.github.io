# subliminal

> Python-based subtitle downloader.

- Download English subtitles for a video:

`subliminal download -l {{en}} {{video.ext}}`
