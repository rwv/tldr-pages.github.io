# google-chrome

> This command is an alias of `chromium`.
> More information: <https://chrome.google.com>.

- View documentation for the original command:

`tldr chromium`
