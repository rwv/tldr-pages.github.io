# logname

> Shows the user's login name.
> More information: <https://www.gnu.org/software/coreutils/logname>.

- Display the currently logged in user's name:

`logname`
