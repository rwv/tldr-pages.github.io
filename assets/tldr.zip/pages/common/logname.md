# logname

> Shows the user's login name.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- Display the currently logged in user's name:

`logname`
