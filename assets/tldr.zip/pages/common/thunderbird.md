# thundebird

> Email client and RSS reader.

- Open thunderbird:

`thunderbird`

- Use a specific user profile directory:

`thunderbird -P {{path/to/profile/directory}}`
