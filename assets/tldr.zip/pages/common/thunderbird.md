# thunderbird

> Email client and RSS reader.
> More information: <https://thunderbird.net>.

- Open thunderbird:

`thunderbird`

- Use a specific user profile:

`thunderbird -P {{profile_name}}`

- Use a specific user profile directory:

`thunderbird --profile {{path/to/profile/directory}}`
