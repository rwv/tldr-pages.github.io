# valac

> Vala code compiler.
> Tutorial: <https://wiki.gnome.org/Projects/Vala/Tutorial>.
> More information: <https://valadoc.org/>.

- Compile a vala file, with gtk+:

`valac {{path/to/file.vala}} --pkg {{gtk+-3.0}}`

- Display version info:

`valac --version`

- Display helper message:

`valac --help`
