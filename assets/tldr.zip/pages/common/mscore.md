# mscore

> This command is an alias of `musescore`.

- View documentation for the original command:

`tldr musescore`
