# yarn-why

> Identifies why a Yarn package has been installed.
> More information: <https://www.npmjs.com/package/yarn-why>.

- Show why a Yarn package is installed:

`yarn-why {{package_name}}`
