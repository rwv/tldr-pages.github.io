# fg

> Run jobs in foreground.
> More information: <https://manned.org/fg>.

- Bring most recently suspended background job to foreground:

`fg`

- Bring a specific job to foreground:

`fg %{{job_id}}`
