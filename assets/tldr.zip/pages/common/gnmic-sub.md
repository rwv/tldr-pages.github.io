# gnmic sub

> This command is an alias of `gnmic subscribe`.
> More information: <https://gnmic.kmrd.dev/cmd/subscribe>.

- View documentation for the original command:

`tldr gnmic subscribe`
