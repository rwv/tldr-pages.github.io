# ebook-convert

> Can be used to convert ebooks between common formats, e.g., pdf, epub and mobi.
> Part of the Calibre ebook library tool.

- Convert an ebook into another format:

`ebook-convert {{source}} {{destination}}`
