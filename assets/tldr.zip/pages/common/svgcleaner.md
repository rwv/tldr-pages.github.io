# svgcleaner

> SVG image optimizing utility.
> More information: <https://github.com/RazrFalcon/svgcleaner>.

- Optimize an SVG image:

`svgcleaner {{input.svg}} {{output.svg}}`

- Optimize an SVG image multiple times:

`svgcleaner --multipass {{input.svg}} {{output.svg}}`
