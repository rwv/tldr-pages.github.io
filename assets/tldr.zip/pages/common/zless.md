# zless

> View compressed files.
> More information: <https://manned.org/zless>.

- Page through a compressed archive with `less`:

`zless {{file.txt.gz}}`
