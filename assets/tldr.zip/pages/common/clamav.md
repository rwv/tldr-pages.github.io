# ClamAV

> Open-source anti-virus program.
> ClamAV isn't a command, but a set of commands.
> More information: <https://www.clamav.net>.

- Show the tldr page for scan files using the `clamd` daemon:

`tldr clamdscan`

- Show the tldr page for scan files without the `clamd` daemon running:

`tldr clamscan`

- Show the tldr page for update the virus definitions:

`tldr freshclam`
