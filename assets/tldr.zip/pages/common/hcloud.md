# hcloud

> Show how to use the CLI for Hetzner Cloud.
> More information: <https://github.com/hetznercloud/cli>.

- Show available commands and flags:

`hcloud`

- Show help for `hcloud`:

`hcloud -h`

- Show available commands and flags for `hcloud` contexts:

`hcloud context`
