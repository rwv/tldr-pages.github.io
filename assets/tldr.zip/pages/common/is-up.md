# is-up

> Check whether a website is up or down.
> More information: <https://github.com/sindresorhus/is-up-cli>.

- Check the status of the specified website:

`is-up {{example.com}}`
