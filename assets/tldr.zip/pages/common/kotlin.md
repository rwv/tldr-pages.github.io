# kotlin

> Kotlin Application Launcher.
> More information <https://kotlinlang.org>.

- Run a jar file:

`kotlin {{filename.jar}}`

- Display Kotlin and JVM version:

`kotlin -version`
