# unlzma

> This command is an alias of `xz --format=lzma --decompress`.
> More information: <https://manned.org/unlzma>.

- View documentation for the original command:

`tldr xz`
