# users

> Display a list of logged in users.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/users-invocation.html>.

- Display a list of logged in users:

`users`

- Display a list of logged in users according to a specific file:

`users {{/var/log/wmtp}}`
