# true

> Returns a successful exit status code of 0.
> Use this with the || operator to make a command always exit with 0.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/true-invocation.html>.

- Return a successful exit code:

`true`
