# nohup

> Allows for a process to live when the terminal gets killed.

- Run process that can live beyond the terminal:

`nohup {{command options}}`
