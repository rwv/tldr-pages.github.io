# nohup

> Allows for a process to live when the terminal gets killed.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/nohup-invocation.html>.

- Run process that can live beyond the terminal:

`nohup {{command}} {{command_options}}`
