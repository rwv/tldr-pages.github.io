# salt-run

> Frontend for executing salt-runners on minions.

- Show status of all minions:

`salt-run manage.status`

- Show all minions which are disconnected:

`salt-run manage.up`
