# salt-run

> Frontend for executing salt-runners on minions.
> More information: <https://docs.saltstack.com/ref/cli/salt-run.html>.

- Show status of all minions:

`salt-run manage.status`

- Show all minions which are disconnected:

`salt-run manage.up`
