# unalias

> Remove aliases.

- Remove an alias:

`unalias {{alias_name}}`

- Remove all aliases:

`unalias -a`
