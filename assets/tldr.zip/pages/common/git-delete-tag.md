# git delete-tag

> Delete existing local and remote tags.
> Part of git-extras.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-delete-tag>.

- Delete a tag:

`git delete-tag {{tag_version}}`
