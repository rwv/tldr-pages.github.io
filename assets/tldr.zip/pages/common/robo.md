# robo

> PHP task runner.
> More information: <https://robo.li/>.

- List available commands:

`robo list`

- Run a specific command:

`robo {{foo}}`

- Simulate running a specific command:

`robo --simulate {{foo}}`
