# ripgrep

> `ripgrep` is the common name for the command `rg`.

- View documentation for the actual command:

`tldr rg`
