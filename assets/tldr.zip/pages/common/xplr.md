# xplr

> Terminal-based file system explorer.
> More information: <https://github.com/sayanarijit/xplr>.

- Open a directory:

`xplr {{path/to/directory}}`

- Focus on a file:

`xplr {{path/to/file}}`
