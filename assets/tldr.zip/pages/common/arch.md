# arch

> Display the name of the system architecture.
> See also `uname`.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Display the system's architecture:

`arch`
