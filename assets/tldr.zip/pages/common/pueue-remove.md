# pueue remove

> Remove tasks from the list. Running or paused tasks need to be killed first.
> More information: <https://github.com/Nukesor/pueue>.

- Remove a killed or finished task:

`pueue remove {{task_id}}`

- Remove multiple tasks at once:

`pueue remove {{task_id}} {{task_id}}`
