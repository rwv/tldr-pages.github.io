# upx

> Compress or decompress executables.
> Homepage: <https://upx.github.io>.

- Compress executable:

`upx {{file}}`

- Decompress executable:

`upx -d {{file}}`

- Detailed help:

`upx --help`
