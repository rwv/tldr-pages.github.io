# gh environment

> Display help about environment variables for the GitHub CLI command.
> More information: <https://cli.github.com/manual/gh_help_environment>.

- Display help about environment variables that can be used with `gh`:

`gh environment`
