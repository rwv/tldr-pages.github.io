# sbcl

> High performance Common Lisp compiler.
> More information: <http://www.sbcl.org/>.

- Start a REPL (interactive shell):

`sbcl`

- Execute a Lisp script:

`sbcl --script {{path/to/script.lisp}}`
