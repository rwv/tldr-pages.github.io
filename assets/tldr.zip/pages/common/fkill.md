# fkill

> Fabulously kill processes. Cross-platform.
> More information: <https://github.com/sindresorhus/fkill>.

- Run without arguments to use the interactive interface:

`fkill`

- Kill the process by PID, name or port:

`fkill {{pid|name|:port}}`
