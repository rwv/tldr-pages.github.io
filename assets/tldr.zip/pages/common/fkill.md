# fkill

> Fabulously kill processes. Cross-platform.
> More information: <https://github.com/sindresorhus/fkill>.

- Run without arguments to use the interactive interface:

`fkill`

- Kill the process by pid, name or port:

`fkill {{pid|name|:port}}`
