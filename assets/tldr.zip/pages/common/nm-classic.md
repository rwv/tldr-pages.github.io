# nm-classic

> This command is an alias of `nm`.

- View documentation for the original command:

`tldr nm`
