# rcat

> This command is an alias of `rc`.

- View documentation for the original command:

`tldr rc`
