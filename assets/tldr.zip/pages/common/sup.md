# sup

> A tool for managing an RSS feed contained in the current directory.
> See also: `lb`.
> More information: <https://github.com/LukeSmithxyz/lb>.

- Add an article to the RSS feed:

`sup {{path/to/file.html}}`
