# git ignore

> Generate .gitignore files from predefined templates.
> More information: <https://docs.gitignore.io/install/command-line>.

- List available templates:

`git ignore list`

- Generate a .gitignore template:

`git ignore {{item_a,item_b,item_n}}`
