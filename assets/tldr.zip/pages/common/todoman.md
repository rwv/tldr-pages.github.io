# todoman

> A simple, standards-based, cli todo manager.
> `todoman` is a common name for the command `todo`, but not a command itself.
> More information: <https://todoman.readthedocs.io/>.

- View documentation for the actual command:

`tldr todo`
