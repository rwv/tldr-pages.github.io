# time

> See how long a command takes.
> More information: <https://manned.org/time>.

- Time "ls":

`time ls`
