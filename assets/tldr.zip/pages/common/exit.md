# exit

> Exit the shell.
> More information: <https://manned.org/exit>.

- Exit the shell with the exit code of the last command executed:

`exit`

- Exit the shell with the specified exit code:

`exit {{exit_code}}`
