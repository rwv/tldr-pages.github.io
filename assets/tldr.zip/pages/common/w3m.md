# w3m

> A text-based web browser.
> More information: <http://w3m.sourceforge.net>.

- Open an URL:

`w3m {{http://example.com}}`

- Quit w3m:

`'q' then 'y'`
