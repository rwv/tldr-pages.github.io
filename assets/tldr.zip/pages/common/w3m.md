# w3m

> A text-based web browser.

- Open an URL:

`w3m {{http://example.com}}`

- Quit w3m:

`'q' then 'y'`
