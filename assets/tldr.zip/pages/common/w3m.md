# w3m

> A text-based web browser.
> Homepage: <http://w3m.sourceforge.net>.

- Open an URL:

`w3m {{http://example.com}}`

- Quit w3m:

`'q' then 'y'`
