# pinta

> Pinta is a free, open source program for drawing and image editing.
> More information: <https://www.pinta-project.com/>.

- Start Pinta:

`pinta`

- Open specific files:

`pinta {{path/to/image1 path/to/image2 ...}}`
