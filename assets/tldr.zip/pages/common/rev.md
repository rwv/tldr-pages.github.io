# rev

> Reverse a line of text.
> More information: <https://manned.org/rev>.

- Reverse the text string "hello":

`echo "hello" | rev`

- Reverse an entire file and print to stdout:

`rev {{file}}`
