# pueue clean

> Remove all finished tasks from the list and clear logs.
> More information: <https://github.com/Nukesor/pueue>.

- Remove finished tasks and clear logs:

`pueue clean`

- Only clean commands that finished successfully:

`pueue clean --successful-only`
