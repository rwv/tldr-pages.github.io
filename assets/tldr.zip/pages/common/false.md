# false

> Returns an exit code of 1.
> More information: <https://www.gnu.org/software/coreutils/false>.

- Return an exit code of 1:

`false`
