# ipcs

> Display information about resources used in IPC (Inter-process Communication).
> More information: <https://manned.org/ipcs>.

- Specific information about the Message Queue which has the ID 32768:

`ipcs -qi 32768`

- General information about all the IPC:

`ipcs -a`
