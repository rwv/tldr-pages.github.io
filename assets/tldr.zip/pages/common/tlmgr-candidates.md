# tlmgr candidates

> Get available candidate repositories from which a TeX Live package can be installed.
> More information: <https://www.tug.org/texlive/tlmgr.html>.

- List all available repositories from which a package can be installed:

`tlmgr candidates {{package}}`
