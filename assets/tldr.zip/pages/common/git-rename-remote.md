# git rename-remote

> Change remote for pulling and pushing.
> Part of `git-extras`.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-rename-remote>.

- Change the upstream remote to origin:

`git rename-remote {{upstream}} {{origin}}`
