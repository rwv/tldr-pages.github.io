# vi

> This command is an alias of `vim`.

- View documentation for the original command:

`tldr vim`
