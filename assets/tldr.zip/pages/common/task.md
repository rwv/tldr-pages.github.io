# task

> TODO list manager.
> More information: <https://manned.org/task>.

- Add new task:

`task add {{thing_to_do}}`

- List tasks:

`task list`

- Mark task as completed:

`task {{task_id}} done`

- Modify task:

`task {{task_id}} modify {{new_thing_to_do}}`

- Delete task:

`task {{task_id}} delete`
