# lzcat

> This command is an alias of `xz --format=lzma --decompress --stdout`.
> More information: <https://manned.org/lzcat>.

- View documentation for the original command:

`tldr xz`
