# autofsd

> Runs `automount` on startup and network configuration change events.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/autofsd/>.

- Start the daemon:

`autofsd`
