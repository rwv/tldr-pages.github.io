# gegrep

> This command is an alias of GNU `egrep`.

- View documentation for the original command:

`tldr -p linux egrep`
