# gid

> This command is an alias of GNU `id`.

- View documentation for the original command:

`tldr -p linux id`
