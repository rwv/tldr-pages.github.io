# hidd

> HID library userland daemon.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/hidd/>.

- Start the daemon:

`hidd`
