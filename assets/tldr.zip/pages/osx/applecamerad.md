# applecamerad

> Camera manager.
> It should not be invoked manually.

- Start the daemon:

`applecamerad`
