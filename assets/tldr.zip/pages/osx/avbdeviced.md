# avbdeviced

> A service for managing Audio Video Bridging (AVB) devices.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/1/avbdeviced/>.

- Start the daemon:

`avbdeviced`
