# xartstorageremoted

> The xART Remote Storage Daemon. Receives save/fetch requests from the CoProcessor.
> It should not be invoked manually.
> More information: <http://www.manpagez.com/man/8/xartstorageremoted/>.

- Start the daemon:

`xartstorageremoted`
