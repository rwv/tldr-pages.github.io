# auvaltool

> AudioUnit validation tool for Mac.
> More information: <https://www.unix.com/man-page/mojave/1/auvaltool>.

- List all [a]vailable AudioUnits of any type:

`auvaltool -a`

- List all [a]vailable AudioUnits of any type with their [l]ocation:

`auvaltool -al`
