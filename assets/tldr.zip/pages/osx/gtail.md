# gtail

> This command is an alias of GNU `tail`.

- View documentation for the original command:

`tldr -p linux tail`
