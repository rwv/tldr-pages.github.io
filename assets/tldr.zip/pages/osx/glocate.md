# glocate

> This command is an alias of GNU `locate`.

- View documentation for the original command:

`tldr -p linux locate`
