# photoanalysisd

> This analyzes photo libraries for Memories, People, and scene or object based search.
> It should not be invoked manually.

- Start the daemon:

`photoanalysisd`
