# cfprefsd

> Provides preferences services (`CFPreferences`, `NSUserDefaults`).
> It should not be invoked manually.

- Start the daemon:

`cfprefsd`
