# gchmod

> This command is an alias of GNU `chmod`.

- View documentation for the original command:

`tldr -p linux chmod`
