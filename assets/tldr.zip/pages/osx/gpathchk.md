# gpathchk

> This command is an alias of GNU `pathchk`.

- View documentation for the original command:

`tldr -p linux pathchk`
