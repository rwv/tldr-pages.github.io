# watchlistd

> Manages the Apple TV app's watch list.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/watchlistd/>.

- Start the daemon:

`watchlistd`
