# genv

> This command is an alias of GNU `env`.

- View documentation for the original command:

`tldr -p linux env`
