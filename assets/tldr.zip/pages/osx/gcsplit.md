# gcsplit

> This command is an alias of GNU `csplit`.

- View documentation for the original command:

`tldr -p linux csplit`
