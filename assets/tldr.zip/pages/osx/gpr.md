# gpr

> This command is an alias of GNU `pr`.

- View documentation for the original command:

`tldr -p linux pr`
