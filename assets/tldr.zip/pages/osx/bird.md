# bird

> This supports the syncing of iCloud and iCloud drive.
> It should not be invoked manually.

- Start the daemon:

`bird`
