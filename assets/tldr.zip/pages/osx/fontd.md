# fontd

> Makes fonts available to the system.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/fontd/>.

- Start the daemon:

`fontd`
