# reboot

> Reboot the system.

- Reboot immediately:

`sudo reboot`

- Reboot immediately without gracefully shutting down:

`sudo reboot -q`
