# gln

> This command is an alias of GNU `ln`.

- View documentation for the original command:

`tldr -p linux ln`
