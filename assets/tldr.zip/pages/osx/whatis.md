# whatis

> Tool that searches a set of database files containing short descriptions of system commands for keywords.
> More information: <http://www.linfo.org/whatis.html>.

- Search for informations about keyword:

`whatis {{keyword}}`

- Search for information about multiple keywords:

`whatis {{first_keyword}} {{second_keyword}}`
