# mdls

> Display the metadata attributes for a file.

- Display the list of metadata attributes for file:

`mdls {{path/to/file}}`

- Display a specific metadata attribute:

`mdls -name {{attribute}} {{path/to/file}}`
