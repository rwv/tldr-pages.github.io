# uptime

> Tell how long the system has been running and other information.
> More information: <https://ss64.com/osx/uptime.html>.

- Print current time, uptime, number of logged-in users and other information:

`uptime`
