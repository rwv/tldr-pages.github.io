# gvdir

> This command is an alias of GNU `vdir`.

- View documentation for the original command:

`tldr -p linux vdir`
