# gwc

> This command is an alias of GNU `wc`.

- View documentation for the original command:

`tldr -p linux wc`
