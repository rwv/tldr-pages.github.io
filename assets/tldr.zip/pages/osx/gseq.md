# gseq

> This command is an alias of GNU `seq`.

- View documentation for the original command:

`tldr -p linux seq`
