# gunexpand

> This command is an alias of GNU `unexpand`.

- View documentation for the original command:

`tldr -p linux unexpand`
