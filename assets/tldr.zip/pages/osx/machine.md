# machine

> Print machine type.
> More information: <https://manned.org/machine>.

- Print CPU architecture:

`machine`
