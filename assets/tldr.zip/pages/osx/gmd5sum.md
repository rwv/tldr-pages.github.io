# gmd5sum

> This command is an alias of GNU `md5sum`.

- View documentation for the original command:

`tldr -p linux md5sum`
