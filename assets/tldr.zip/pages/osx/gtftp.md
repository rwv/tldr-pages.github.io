# gtftp

> This command is an alias of GNU `tftp`.

- View documentation for the original command:

`tldr -p linux tftp`
