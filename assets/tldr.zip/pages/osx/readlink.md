# readlink

> Follow symlinks and get symlink information.
> More information: <https://www.gnu.org/software/coreutils/readlink>.

- Print the absolute path which the symlink points to:

`readlink {{path/to/symlink}}`
