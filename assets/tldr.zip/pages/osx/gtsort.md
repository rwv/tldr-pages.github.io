# gtsort

> This command is an alias of GNU `tsort`.

- View documentation for the original command:

`tldr -p linux tsort`
