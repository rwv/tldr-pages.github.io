# gb2sum

> This command is an alias of GNU `b2sum`.

- View documentation for the original command:

`tldr -p linux b2sum`
