# gexpr

> This command is an alias of GNU `expr`.

- View documentation for the original command:

`tldr -p linux expr`
