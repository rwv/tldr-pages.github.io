# watchdogd

> Works with the Watchdog KEXT to ensure that the system is healthy and running.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/watchdogd/>.

- Start the daemon:

`watchdogd`
