# securityd

> This manages security contexts and cryptographic operations.
> Works with secd for keychain access.
> It should not be invoked manually.

- Start the daemon:

`securityd`
