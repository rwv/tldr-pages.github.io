# biometrickitd

> Provides support for biometric operations.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/biometrickitd/>.

- Start the daemon:

`biometrickitd`
