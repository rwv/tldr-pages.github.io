# cpuid

> Display detailed information about all CPUs.

- Display information for all CPUs:

`cpuid`

- Display information only for the current CPU:

`cpuid -1`

- Display raw hex information with no decoding:

`cpuid -r`
