# reset

> Reinitializes the current terminal. Clears the entire terminal screen.
> More information: <https://manned.org/reset>.

- Reinitialize the current terminal:

`reset`

- Display the terminal type instead:

`reset -q`
