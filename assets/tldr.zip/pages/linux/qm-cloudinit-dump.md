# qm cloudinit dump

> Generate cloudinit configuration files.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Generate a cloudinit file for a specific configuration type:

`qm cloudinit dump {{vmid}} {{meta|network|user}}`
