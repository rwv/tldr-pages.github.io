# wtf

> Show the expansions of acronyms.
> More information: <https://manpages.debian.org/bsdgames/wtf.6.en.html>.

- Expand a given acronym:

`wtf {{IMO}}`

- Specify a computer related search type:

`wtf -t {{comp}} {{WWW}}`
