# ubuntu-bug

> This command is an alias of `apport-bug`.

- View documentation for the original command:

`tldr apport-bug`
