# see

> Alias to `run-mailcap`'s view.
> An alias to a `run-mailcap`'s action print.
> More information: <https://manned.org/see>.

- See action can be used to view any file (usually image) on default mailcap explorer:

`see {{filename}}`

- Using with `run-mailcap`:

`run-mailcap --action=view {{filename}}`
