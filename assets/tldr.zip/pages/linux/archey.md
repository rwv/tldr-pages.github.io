# archey

> Simple tool for stylishly displaying system information.
> More information: <https://lclarkmichalek.github.io/archey3/>.

- Show system information:

`archey`
