# runsvchdir

> Change the directory `runsvdir` uses by default.
> More information: <http://manpages.ubuntu.com/manpages/focal/man8/runsvchdir.8.html>.

- Switch `runsvdir` directories:

`sudo runsvchdir {{path/to/directory}}`
