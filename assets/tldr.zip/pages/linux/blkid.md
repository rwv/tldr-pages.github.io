# blkid

> Lists all recognized partitions and their Universally Unique Identifier (UUID).

- List all partitions:

`sudo blkid`

- List all partitions in a table, including current mountpoints:

`sudo blkid -o list`
