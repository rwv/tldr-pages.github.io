# nmcli monitor

> Monitor changes to the NetworkManager connection status.
> More information: <https://developer.gnome.org/NetworkManager/stable/nmcli.html>.

- Start monitoring NetworkManager changes:

`nmcli monitor`
