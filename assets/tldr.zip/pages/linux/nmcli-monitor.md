# nmcli monitor

> Monitor changes to the NetworkManager connection status.
> More information: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Start monitoring NetworkManager changes:

`nmcli monitor`
