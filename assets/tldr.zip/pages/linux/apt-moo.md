# apt moo

> An `APT` easter egg.
> More information: <https://manpages.debian.org/latest/apt/apt.8.html>.

- Print a cow easter egg:

`apt moo`
