# qm guest exec-status

> Print the status of the given pid started by the guest-agent on QEMU/KVM Virtual Machine Manager.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Print the status of a specific PID:

`qm guest exec-status {{vm_id}} {{pid}}`
