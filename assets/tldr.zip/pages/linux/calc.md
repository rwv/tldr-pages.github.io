# calc

> An interactive arbitrary-precision calculator on the terminal.
> More information: <https://github.com/lcn2/calc>.

- Start calc in interactive mode:

`calc`

- Perform a calculation in non-interactive mode:

`calc -p '{{85 * (36 / 4)}}'`
