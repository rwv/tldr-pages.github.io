# acpi

> Shows battery status or thermal information.

- Show battery information:

`acpi`

- Show thermal information:

`acpi -t`

- Show cooling device information:

`acpi -c`

- Show thermal information in Fahrenheit:

`acpi -tf`

- Show all information:

`acpi -V`
