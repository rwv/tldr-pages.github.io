# mate-calc-cmd

> Calculate mathematic expressions in MATE desktop environment in terminal.
> More information: <https://manned.org/mate-calc-cmd>.

- Start an interactive calculator session:

`mate-calc-cmd`

- Calculate a specific mathematic expression:

`{{2 + 5}}`
