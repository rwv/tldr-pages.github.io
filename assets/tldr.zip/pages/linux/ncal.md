# ncal

> This command is an alias of `cal`.

- View documentation for the original command:

`tldr cal`
