# ul

> Performs the underlining of a text.
> Each character in a given string must be underlined separately.

- Display the contents of the file with underlines where applicable:

`ul {{file.txt}}`

- Display the contents of the file with underlines made of dashes `-`:

`ul -i {{file.txt}}`
