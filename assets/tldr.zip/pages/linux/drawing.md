# drawing

> Free basic raster image editor in GNOME desktop environment.
> More information: <https://maoschanz.github.io/drawing/>.

- Start Drawing:

`drawing`

- Open specific files:

`drawing {{path/to/image1 path/to/image2 ...}}`

- Open specific files in a new window:

`drawing --new-window {{path/to/image1 path/to/image2 ...}}`
