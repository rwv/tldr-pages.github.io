# caffeine

> Prevent desktop idleness in full-screen mode.
> More information: <https://manned.org/caffeine>.

- Start a caffeine server:

`caffeine`

- Display help:

`caffeine --help`

- Display version:

`caffeine --version`
