# pkgrm

> Remove a package from a CRUX system.

- Remove an installed package:

`pkgrm {{package_name}}`
