# pkgrm

> Remove a package from a CRUX system.
> More information: <https://docs.oracle.com/cd/E86824_01/html/E54764/pkgrm-1m.html>.

- Remove an installed package:

`pkgrm {{package_name}}`
