# ifdown

> Disable network interfaces.

- Disable interface eth0:

`ifdown {{eth0}}`

- Disable all interfaces which are enabled:

`ifdown -a`
