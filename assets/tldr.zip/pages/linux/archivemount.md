# archivemount

> Mount an archive for access as a filesystem.
> More information: <https://manned.org/archivemount>.

- Mount an archive to a specific mountpoint:

`archivemount {{path/to/archive}} {{path/to/mount_point}}`
