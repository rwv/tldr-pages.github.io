# anbox

> Run Android applications on any GNU/Linux operating system.
> More information: <https://manned.org/anbox>.

- Launch Anbox into the app manager:

`anbox launch --package={{org.anbox.appmgr}} --component={{org.anbox.appmgr.AppViewActivity}}`
