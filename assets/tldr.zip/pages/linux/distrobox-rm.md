# distrobox-rm

> Delete Distrobox containers.
> More information: <https://distrobox.privatedns.org>.

- Remove a distrobox:

`distrobox-rm {{container_name}}`

- Remove a distrobox forcefully:

`distrobox-rm {{container_name}} --force`
