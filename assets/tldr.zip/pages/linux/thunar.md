# thunar

> Graphical file manager for XFCE desktop environments.

- Open a new window showing the current directory:

`thunar`

- Open the bulk rename utility:

`thunar --bulk-rename`

- Close all open thunar windows:

`thunar --quit`
