# qm monitor

> Enter the QEMU Monitor interface.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Enter the QEMU Monitor interface of a specific virtual machine:

`qm monitor {{vm_id}}`
