# ifup

> Tool used to enable network interfaces.

- Enable interface eth0:

`ifup {{eth0}}`

- Enable all the interfaces defined with "auto" in /etc/network/interfaces:

`ifup -a`
