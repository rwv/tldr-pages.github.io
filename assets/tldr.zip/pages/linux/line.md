# line

> Read a single line of input.
> More information: <https://manned.org/line>.

- Read input:

`line`
