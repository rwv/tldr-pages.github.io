# cc

> This command is an alias of `gcc`.
> More information: <https://gcc.gnu.org>.

- View documentation for the original command:

`tldr gcc`
