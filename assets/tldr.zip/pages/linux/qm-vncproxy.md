# qm vncproxy

> Proxy Virtual Machine VNC (Virtual network computing) traffic to stdin/stdout.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Proxy a specific virtual machine:

`qm vncproxy {{vm_id}}`
