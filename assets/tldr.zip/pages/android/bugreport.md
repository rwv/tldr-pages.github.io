# bugreport

> Show an Android bug report.
> This command can only be used through `adb shell`.
> More information: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreport>.

- Show a complete bug report of an Android device:

`bugreport`
