# bugreport

> Show an Android bug report.
> This command can only be used through `adb shell`.
> More information: <https://android.googlesource.com/platform/frameworks/native/+/master/cmds/bugreport/>.

- Show a complete bug report of an Android device:

`bugreport`
