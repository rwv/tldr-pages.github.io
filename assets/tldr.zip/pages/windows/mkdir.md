# mkdir

> Creates a directory.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- Create a directory:

`mkdir {{directory_name}}`

- Recursively create a nested directory tree:

`mkdir {{path/to/sub_directory_name}}`
