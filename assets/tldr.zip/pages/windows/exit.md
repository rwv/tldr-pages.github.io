# exit

> Quit the current CMD instance or the current batch file.
> More information: <https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/exit>.

- Quit the current CMD instance:

`exit`

- Quit the current batch script:

`exit /b`

- Quit using a specific exit code:

`exit {{exit_code}}`
