# clist

> This command is an alias of `choco list`.

- View documentation for the original command:

`tldr choco list`
