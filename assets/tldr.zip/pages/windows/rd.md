# rd

> This command is an alias of `rmdir`.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- View documentation for the original command:

`tldr rmdir`
