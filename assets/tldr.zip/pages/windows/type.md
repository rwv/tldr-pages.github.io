# type

> Display the contents of a file.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/type>.

- Display the contents of a specific file:

`type {{path/to/file}}`
