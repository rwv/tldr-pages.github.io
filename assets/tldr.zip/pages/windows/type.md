# type

> Display the contents of a file.
> More information: <https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/type>.

- Display the contents of a specific file:

`type {{path/to/file}}`
