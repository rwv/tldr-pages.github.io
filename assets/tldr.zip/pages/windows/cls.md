# cls

> Clears the screen.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Clear the screen:

`cls`
