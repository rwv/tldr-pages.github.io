# sls

> This command is an alias of `Select-String`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- View documentation for the original command:

`tldr where-object`
